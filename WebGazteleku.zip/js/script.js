
// Ermuko Gaztelekuaren webguneko funtzio orokorrak


// --------------------------------------------------
// KATEGORIAK ETA ARGAZKIAK
// --------------------------------------------------

const kategoriak = {

    AISIALDIA: {
        izena: "Aisialdia",
        deskribapena: "Aisialdiaz gozatzeko eta lagunekin egoteko ekintzak.",
        irudiak: [
            "irudiak/AISIALDIA/aisialdia1.jpeg",
            "irudiak/AISIALDIA/aisialdia2.jpeg",
            "irudiak/AISIALDIA/aisialdia3.jpeg"
        ]
    },

    KIROLAK: {
        izena: "Kirolak",
        deskribapena: "Mugitu, kirola egin eta taldean gozatzeko ekintzak.",
        irudiak: [
            "irudiak/KIROLAK/kirolak1.jpeg",
            "irudiak/KIROLAK/kirolak2.jpeg",
            "irudiak/KIROLAK/kirolak3.jpeg"
        ]
    },

    KULTURALA: {
        izena: "Kulturala",
        deskribapena: "Sormena, artea eta kultura lantzeko ekintzak.",
        irudiak: [
            "irudiak/KULTURALA/kulturala1.jpeg",
            "irudiak/KULTURALA/kulturala2.jpeg",
            "irudiak/KULTURALA/kulturala3.jpeg"
        ]
    },

    NATURA: {
        izena: "Natura",
        deskribapena: "Naturarekin harremanetan egoteko eta ingurunea ezagutzeko ekintzak.",
        irudiak: [
            "irudiak/NATURA/natura1.jpeg",
            "irudiak/NATURA/natura2.jpeg",
            "irudiak/NATURA/natura3.jpeg"
        ]
    },

    SUKALDARITZA: {
        izena: "Sukaldaritza",
        deskribapena: "Sukaldaritza ikasi eta errezeta berriak prestatzeko ekintzak.",
        irudiak: [
            "irudiak/SUKALDARITZA/sukaldaritza1.jpeg",
            "irudiak/SUKALDARITZA/sukaldaritza2.jpeg",
            "irudiak/SUKALDARITZA/sukaldaritza3.jpeg"
        ]
    }

};


// --------------------------------------------------
// EKINTZEN ZERRENDA
// --------------------------------------------------

const ekintzak = [

    {
        id: 1,
        izena: "Bideo-joko arratsaldea",
        kategoria: "AISIALDIA",
        data: "2026-11-15",
        lekua: "Gaztelekua",
        plazak: 16,
        deskribapena: "Jolastu, partekatu eta ezagutu jolas berriak."
    },

    {
        id: 2,
        izena: "Kirol jardunaldia",
        kategoria: "KIROLAK",
        data: "2026-11-18",
        lekua: "Kirol instalazioak",
        plazak: 20,
        deskribapena: "Kirol desberdinak probatzeko eta taldean aritzeko aukera."
    },

    {
        id: 3,
        izena: "Sormen tailerra",
        kategoria: "KULTURALA",
        data: "2026-11-05",
        lekua: "Gaztelekua",
        plazak: 15,
        deskribapena: "Margotu, diseinatu eta sortu zure ideiak."
    },

    {
        id: 4,
        izena: "Mendi irteera",
        kategoria: "NATURA",
        data: "2026-11-12",
        lekua: "Plaza",
        plazak: 20,
        deskribapena: "Naturaz gozatzeko talde-irteera."
    },

    {
        id: 5,
        izena: "Sukaldaritza gaztea",
        kategoria: "SUKALDARITZA",
        data: "2026-11-08",
        lekua: "Sukaldea",
        plazak: 12,
        deskribapena: "Errezeta errazak eta talde-lana."
    }

];


// Une honetan aukeratutako kategoria eta argazkia

let aukeratutakoKategoria = "AISIALDIA";
let unekoIrudia = 0;


// --------------------------------------------------
// HTML SEGURUA
// --------------------------------------------------

function htmlSegurua(testua) {

    return String(testua).replace(/[&<>"']/g, karakterea => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[karakterea]);

}


// --------------------------------------------------
// KATEGORIA AUKERATZEA
// --------------------------------------------------

function kategoriakPrestatu() {

    const botoiak = document.querySelectorAll(".category-btn");

    botoiak.forEach(botoia => {

        botoia.addEventListener("click", () => {

            aukeratutakoKategoria = botoia.dataset.category;

            // Aukeratutako botoia nabarmendu

            botoiak.forEach(b => b.classList.remove("active"));

            botoia.classList.add("active");

            // Kategoria berriaren edukia erakutsi

            unekoIrudia = 0;

            argazkiaErakutsi();
            ekintzakErakutsi();

        });

    });

}


// --------------------------------------------------
// KARRUSELA
// --------------------------------------------------

function argazkiaErakutsi() {

    const kategoria = kategoriak[aukeratutakoKategoria];

    const irudia = document.getElementById("categoryImage");
    const izenburua = document.getElementById("carouselCaption");
    const adierazleak = document.getElementById("carouselIndicators");

    if (!irudia || !kategoria) return;

    // Uneko argazkia erakutsi

    irudia.src = kategoria.irudiak[unekoIrudia];

    irudia.alt = kategoria.izena + " kategoriako argazkia";

    izenburua.textContent = kategoria.izena;


    // Argazkien adierazleak sortu

    adierazleak.innerHTML = "";

    kategoria.irudiak.forEach((argazkia, indizea) => {

        const puntua = document.createElement("button");

        puntua.className = "carousel-dot";

        if (indizea === unekoIrudia) {
            puntua.classList.add("active");
        }

        puntua.setAttribute("aria-label", `Argazkia ${indizea + 1}`);

        puntua.addEventListener("click", () => {

            unekoIrudia = indizea;

            argazkiaErakutsi();

        });

        adierazleak.appendChild(puntua);

    });

}


// Aurreko argazkia

function aurrekoArgazkia() {

    const irudiKopurua = kategoriak[aukeratutakoKategoria].irudiak.length;

    unekoIrudia--;

    if (unekoIrudia < 0) {
        unekoIrudia = irudiKopurua - 1;
    }

    argazkiaErakutsi();

}


// Hurrengo argazkia

function hurrengoArgazkia() {

    const irudiKopurua = kategoriak[aukeratutakoKategoria].irudiak.length;

    unekoIrudia++;

    if (unekoIrudia >= irudiKopurua) {
        unekoIrudia = 0;
    }

    argazkiaErakutsi();

}


// Karruselaren botoiak prestatu

function karruselaPrestatu() {

    const aurrekoa = document.getElementById("previousImage");
    const hurrengoa = document.getElementById("nextImage");

    if (aurrekoa) {
        aurrekoa.addEventListener("click", aurrekoArgazkia);
    }

    if (hurrengoa) {
        hurrengoa.addEventListener("click", hurrengoArgazkia);
    }

}


// --------------------------------------------------
// EKINTZAK ERAKUTSI
// --------------------------------------------------

function ekintzakErakutsi() {

    const edukiontzia = document.getElementById("activitiesGrid");

    if (!edukiontzia) return;

    const kategoria = kategoriak[aukeratutakoKategoria];

    // Aukeratutako kategoriako ekintzak bakarrik hartu

    const kategoriakoEkintzak = ekintzak.filter(
        ekintza => ekintza.kategoria === aukeratutakoKategoria
    );


    // Izenburua eta deskribapena eguneratu

    document.getElementById("activityCategoryTitle").textContent =
        kategoria.izena + " kategoriako ekintzak";

    document.getElementById("activityCategoryDescription").textContent =
        kategoria.deskribapena;


    // Ekintzak sortu

    if (kategoriakoEkintzak.length === 0) {

        edukiontzia.innerHTML = `
            <div class="card">
                <p>Momentuz ez dago kategoria honetako ekintzarik.</p>
            </div>
        `;

        return;

    }


    edukiontzia.innerHTML = kategoriakoEkintzak.map(ekintza => `

        <article class="card activity">

            <div class="emoji">📅</div>

            <span class="tag">
                ${htmlSegurua(ekintza.data)}
            </span>

            <h3>${htmlSegurua(ekintza.izena)}</h3>

            <p>${htmlSegurua(ekintza.deskribapena)}</p>

            <p class="muted" style="font-size:13px">
                📍 ${htmlSegurua(ekintza.lekua)}
                · ${ekintza.plazak} plaza
            </p>

            <a class="btn blue"
               href="izena-eman.html?ekintza=${ekintza.id}">
                Izena eman →
            </a>

        </article>

    `).join("");

}


// --------------------------------------------------
// IZEN EMATEKO FORMULARIOA
// --------------------------------------------------

function izenEmateFormularioaPrestatu() {

    const formularioa = document.getElementById("signupForm");

    if (!formularioa) return;

    const hautatzailea = document.getElementById("sEkintza");

    hautatzailea.innerHTML = `
        <option value="">Aukeratu ekintza bat…</option>

        ${ekintzak.map(ekintza => `
            <option value="${ekintza.id}">
                ${htmlSegurua(ekintza.izena)} — ${htmlSegurua(ekintza.data)}
            </option>
        `).join("")}
    `;


    const parametroak = new URLSearchParams(window.location.search);

    const ekintzaID = parametroak.get("ekintza");

    if (ekintzaID) {
        hautatzailea.value = ekintzaID;
    }


    formularioa.addEventListener("submit", event => {

        event.preventDefault();

        const izena = document.getElementById("sIzena").value.trim();

        const abizena = document.getElementById("sAbizena").value.trim();

        const ekintza = ekintzak.find(
            item => String(item.id) === hautatzailea.value
        );


        if (!ekintza) {

            alert("Mesedez, aukeratu ekintza bat.");

            hautatzailea.focus();

            return;

        }


        const oharra = document.getElementById("signupNotice");

        oharra.textContent =
            `Eskerrik asko, ${izena} ${abizena}! ${ekintza.izena} ekintzarako formularioa bete duzu.`;

        oharra.style.display = "block";

        formularioa.reset();

        hautatzailea.value = "";

    });

}


// --------------------------------------------------
// BAZKIDEEN SAIO HASIERA
// --------------------------------------------------

function bazkideSaioaPrestatu() {

    const formularioa = document.getElementById("memberLogin");

    if (!formularioa) return;

    formularioa.addEventListener("submit", event => {

        event.preventDefault();

        const oharra = document.getElementById("memberNotice");

        oharra.textContent =
            "Formularioa bete da. Benetako saio-hasiera eta kontuen egiaztapena egiteko zerbitzari bat eta autentifikazio-sistema behar dira.";

        oharra.style.display = "block";

    });

}


// --------------------------------------------------
// HASIERAKO FUNTZIOAK
// --------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {

    kategoriakPrestatu();

    karruselaPrestatu();

    argazkiaErakutsi();

    ekintzakErakutsi();

    izenEmateFormularioaPrestatu();

    bazkideSaioaPrestatu();

});





//<!-- Comentario original: lógica JavaScript -->
//	<!-- JAVASCRIPT LOGIKA -->
//	<!-- Abre el bloque de JavaScript (al final del body para que el HTML ya exista cuando se ejecute) -->
//	<script>
		// Comentario original: cargar iconos
		// Ikonoak kargatu
		// Lucide busca todos los <i data-lucide="..."> y los reemplaza por el SVG del icono correspondiente
		lucide.createIcons();

		// Comentario original: alternar (toggle) el menú móvil
		// Mobil Menua Txandakatu (Toggle)
		// Guarda en una constante el botón hamburguesa, buscándolo por su id
		const menuBtn = document.getElementById('mobile-menu-btn');
		// Guarda en una constante el panel del menú móvil
		const mobileMenu = document.getElementById('mobile-menu');

		// Escucha el evento 'click' del botón; al ocurrir, ejecuta la función flecha (arrow function)
		menuBtn.addEventListener('click', () => {
			// classList.toggle: si el panel tiene la clase 'hidden' se la quita (se muestra); si no la tiene, se la pone (se oculta)
			mobileMenu.classList.toggle('hidden');
		// Cierra la función y la llamada a addEventListener
		});

		// Comentario original: al pulsar un enlace del menú móvil, cerrar el menú
		// Mobil menuko lotura bat sakatzean menua itxi
		// querySelectorAll devuelve TODOS los <a> dentro de #mobile-menu; forEach recorre cada uno (la variable 'link' es el enlace actual)
		document.querySelectorAll('#mobile-menu a').forEach(link => {
			// A cada enlace se le añade un listener de clic
			link.addEventListener('click', () => {
				// Al hacer clic, añade la clase 'hidden' = cierra el menú (el enlace ancla ya hace el scroll)
				mobileMenu.classList.add('hidden');
			// Cierra el listener del enlace
			});
		// Cierra el forEach
		});
//	<!-- Cierra el bloque de JavaScript -->
//	</script>