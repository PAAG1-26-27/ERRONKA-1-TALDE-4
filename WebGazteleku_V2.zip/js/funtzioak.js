// Ermuko Gaztelekuaren webguneko funtzio orokorrak
// General functions for the Ermuko Gaztelekua website.
// If a page shows activities, categories or the signup form, load datuak.js BEFORE this file.


// Une honetan aukeratutako kategoria eta argazkia
// Currently selected category and image index (0 = first image)

let aukeratutakoKategoria = "AISIALDIA";
let unekoIrudia = 0;


// --------------------------------------------------
// HTML SEGURUA
// --------------------------------------------------

// Escapes special characters (& < > " ') so text can't be read as real HTML.
// Use it on any text inserted into the page with innerHTML.

function htmlSegurua(testua) {

    return String(testua).replace(/[&<>"']/g, karakterea => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[karakterea]);

}


// --------------------------------------------------
// KATEGORIA AUKERATZEA
// --------------------------------------------------

// Adds a click listener to every category button.
// On click: saves the chosen category, highlights the button,
// resets the carousel to the first image and redraws image and activities.

function kategoriakPrestatu() {

    const botoiak = document.querySelectorAll(".category-btn");

    botoiak.forEach(botoia => {

        botoia.addEventListener("click", () => {

            // The category key comes from the button's data-category attribute
            aukeratutakoKategoria = botoia.dataset.category;

            // Aukeratutako botoia nabarmendu
            // Highlight only the clicked button

            botoiak.forEach(b => b.classList.remove("active"));

            botoia.classList.add("active");

            // Kategoria berriaren edukia erakutsi
            // Show the content of the new category

            unekoIrudia = 0;

            argazkiaErakutsi();
            ekintzakErakutsi();

        });

    });

}


// --------------------------------------------------
// KARRUSELA
// --------------------------------------------------

// Shows the current image of the selected category and builds
// one clickable dot per image (the dots replace the old prev/next buttons).

function argazkiaErakutsi() {

    // Page without datuak.js: nothing to show --- this is done to preevent errors that don't load the page
    if (typeof kategoriak === "undefined") return;

    const kategoria = kategoriak[aukeratutakoKategoria];

    const irudia = document.getElementById("categoryImage");
    const izenburua = document.getElementById("carouselCaption");
    const adierazleak = document.getElementById("carouselIndicators");

    // Stop if the page has no carousel or the category doesn't exist
    if (!irudia || !kategoria) return;

    // Uneko argazkia erakutsi
    // Show the current image

    irudia.src = kategoria.irudiak[unekoIrudia];

    irudia.alt = kategoria.izena + " kategoriako argazkia";

    izenburua.textContent = kategoria.izena;


    // Argazkien adierazleak sortu
    // Build the image indicator dots

    adierazleak.innerHTML = "";

    kategoria.irudiak.forEach((argazkia, indizea) => {

        const puntua = document.createElement("button");

        puntua.className = "carousel-dot";

        // The dot of the current image is marked as active
        if (indizea === unekoIrudia) {
            puntua.classList.add("active");
        }

        puntua.setAttribute("aria-label", `Argazkia ${indizea + 1}`);

        // Clicking a dot jumps to that image
        puntua.addEventListener("click", () => {

            unekoIrudia = indizea;

            argazkiaErakutsi();

        });

        adierazleak.appendChild(puntua);

    });

}



// --------------------------------------------------
// EKINTZAK ERAKUTSI
// --------------------------------------------------

// Draws the activity cards of the selected category inside #activitiesGrid.

function ekintzakErakutsi() {

    // Page without datuak.js: nothing to show
    if (typeof ekintzak === "undefined" || typeof kategoriak === "undefined") return;

    const edukiontzia = document.getElementById("activitiesGrid");

    // Stop if this page has no activities container
    if (!edukiontzia) return;

    const kategoria = kategoriak[aukeratutakoKategoria];

    // Aukeratutako kategoriako ekintzak bakarrik hartu
    // Keep only the activities of the selected category

    const kategoriakoEkintzak = ekintzak.filter(
        ekintza => ekintza.kategoria === aukeratutakoKategoria
    );


    // Izenburua eta deskribapena eguneratu
    // Update the section title and description

    document.getElementById("activityCategoryTitle").textContent =
        kategoria.izena + " kategoriako ekintzak";

    document.getElementById("activityCategoryDescription").textContent =
        kategoria.deskribapena;


    // Ekintzak sortu
    // Build the cards (or an empty-state message)

    if (kategoriakoEkintzak.length === 0) {

        edukiontzia.innerHTML = `
            <div class="card">
                <p>Momentuz ez dago kategoria honetako ekintzarik.</p>
            </div>
        `;

        return;

    }


    // .map() turns each activity into a block of HTML,
    // .join("") merges all blocks into one string for innerHTML

    edukiontzia.innerHTML = kategoriakoEkintzak.map(ekintza => `

        <article class="card activity">

            <div class="emoji">📅</div>

            <span class="tag">
                ${htmlSegurua(ekintza.data)}
            </span>

            <h3>${htmlSegurua(ekintza.izena)}</h3>

            <p>${htmlSegurua(ekintza.deskribapena)}</p>

            <p class="muted" style="font-size:13px">
                📍 ${htmlSegurua(ekintza.lekua)}
                · ${ekintza.plazak} plaza
            </p>

            <a class="btn blue"
               href="izena-eman.html?ekintza=${ekintza.id}">
                Izena eman →
            </a>

        </article>

    `).join("");

}


// --------------------------------------------------
// IZEN EMATEKO FORMULARIOA
// --------------------------------------------------

// Fills the activity dropdown, preselects the activity from the URL
// (?ekintza=ID) and handles the form submission.

function izenEmateFormularioaPrestatu() {

    // Page without datuak.js: nothing to prepare
    if (typeof ekintzak === "undefined") return;

    const formularioa = document.getElementById("signupForm");

    // Stop if this page has no signup form
    if (!formularioa) return;

    const hautatzailea = document.getElementById("sEkintza");

    // One <option> per activity, plus an empty first option
    hautatzailea.innerHTML = `
        <option value="">Aukeratu ekintza bat…</option>

        ${ekintzak.map(ekintza => `
            <option value="${ekintza.id}">
                ${htmlSegurua(ekintza.izena)} — ${htmlSegurua(ekintza.data)}
            </option>
        `).join("")}
    `;


    // Read the activity id from the address (e.g. izena-eman.html?ekintza=7)
    const parametroak = new URLSearchParams(window.location.search);

    const ekintzaID = parametroak.get("ekintza");

    if (ekintzaID) {
        hautatzailea.value = ekintzaID;
    }


    formularioa.addEventListener("submit", event => {

        // Prevent the browser's default form submission (page reload)
        event.preventDefault();

        const izena = document.getElementById("sIzena").value.trim();

        const abizena = document.getElementById("sAbizena").value.trim();

        // Find the chosen activity (ids are compared as text)
        const ekintza = ekintzak.find(
            item => String(item.id) === hautatzailea.value
        );


        // No activity chosen: warn and stop
        if (!ekintza) {

            alert("Mesedez, aukeratu ekintza bat.");

            hautatzailea.focus();

            return;

        }


        // Show a thank-you message and clear the form
        const oharra = document.getElementById("signupNotice");

        oharra.textContent =
            `Eskerrik asko, ${izena} ${abizena}! ${ekintza.izena} ekintzarako formularioa bete duzu.`;

        oharra.style.display = "block";

        formularioa.reset();

        hautatzailea.value = "";

    });

}


// --------------------------------------------------
// BAZKIDEEN SAIO HASIERA
// --------------------------------------------------

// Member login form. It's only a demo: it shows a notice, no real login.

function bazkideSaioaPrestatu() {

    const formularioa = document.getElementById("memberLogin");

    // Stop if this page has no login form
    if (!formularioa) return;

    formularioa.addEventListener("submit", event => {

        event.preventDefault();

        const oharra = document.getElementById("memberNotice");

        oharra.textContent =
            "Formularioa bete da. Benetako saio-hasiera eta kontuen egiaztapena egiteko zerbitzari bat eta autentifikazio-sistema behar dira.";

        oharra.style.display = "block";

    });

}


// --------------------------------------------------
// HASIERAKO FUNTZIOAK
// --------------------------------------------------

// When the page's HTML is ready, start everything.
// Each function checks by itself whether its elements exist on this page.

document.addEventListener("DOMContentLoaded", () => {

    kategoriakPrestatu();

    argazkiaErakutsi();

    ekintzakErakutsi();

    izenEmateFormularioaPrestatu();

    bazkideSaioaPrestatu();

});





//<!-- Comentario original: lógica JavaScript -->
//	<!-- JAVASCRIPT LOGIKA -->
//	<!-- Abre el bloque de JavaScript (al final del body para que el HTML ya exista cuando se ejecute) -->
//	<script>
		// Comentario original: cargar iconos
		// Ikonoak kargatu
		// Lucide busca todos los <i data-lucide="..."> y los reemplaza por el SVG del icono correspondiente
		// (Added guard: only runs if the Lucide library is loaded on this page)
		if (typeof lucide !== "undefined") {
			lucide.createIcons();
		}

		// Comentario original: alternar (toggle) el menú móvil
		// Mobil Menua Txandakatu (Toggle)
		// Guarda en una constante el botón hamburguesa, buscándolo por su id
		const menuBtn = document.getElementById('mobile-menu-btn');
		// Guarda en una constante el panel del menú móvil
		const mobileMenu = document.getElementById('mobile-menu');

		// (Added guard: only runs if this page has the mobile menu)
		if (menuBtn && mobileMenu) {

			// Escucha el evento 'click' del botón; al ocurrir, ejecuta la función flecha (arrow function)
			menuBtn.addEventListener('click', () => {
				// classList.toggle: si el panel tiene la clase 'hidden' se la quita (se muestra); si no la tiene, se la pone (se oculta)
				mobileMenu.classList.toggle('hidden');
			// Cierra la función y la llamada a addEventListener
			});

			// Comentario original: al pulsar un enlace del menú móvil, cerrar el menú
			// Mobil menuko lotura bat sakatzean menua itxi
			// querySelectorAll devuelve TODOS los <a> dentro de #mobile-menu; forEach recorre cada uno (la variable 'link' es el enlace actual)
			document.querySelectorAll('#mobile-menu a').forEach(link => {
				// A cada enlace se le añade un listener de clic
				link.addEventListener('click', () => {
					// Al hacer clic, añade la clase 'hidden' = cierra el menú (el enlace ancla ya hace el scroll)
					mobileMenu.classList.add('hidden');
				// Cierra el listener del enlace
				});
			// Cierra el forEach
			});

		}
//	<!-- Cierra el bloque de JavaScript -->
//	</script>
