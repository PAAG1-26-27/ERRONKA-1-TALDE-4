// Ermuko Gaztelekuaren webguneko datuak
// Data for the Ermuko Gaztelekua website (categories, images and activities).
// Load this file BEFORE funtzioak.js, and only on pages that show this data.


// --------------------------------------------------
// KATEGORIAK ETA ARGAZKIAK
// --------------------------------------------------

const kategoriak = {

    AISIALDIA: {
        izena: "Aisialdia",
        deskribapena: "Aisialdiaz gozatzeko eta lagunekin egoteko ekintzak.",
        irudiak: [
            "irudiak/AISIALDIA/aisialdia1.jpeg",
            "irudiak/AISIALDIA/aisialdia2.jpeg",
            "irudiak/AISIALDIA/aisialdia3.jpeg",
            "irudiak/AISIALDIA/aisialdia4.jpg",
            "irudiak/AISIALDIA/aisialdia5.jpg"
        ]
    },

    KIROLAK: {
        izena: "Kirolak",
        deskribapena: "Mugitu, kirola egin eta taldean gozatzeko ekintzak.",
        irudiak: [
            "irudiak/KIROLAK/kirolak1.jpeg",
            "irudiak/KIROLAK/kirolak2.jpg",
            "irudiak/KIROLAK/kirolak3.jpeg",
            "irudiak/KIROLAK/kirolak4.jpg",
            "irudiak/KIROLAK/kirolak5.jpg"
        ]
    },

    KULTURALA: {
        izena: "Kulturala",
        deskribapena: "Sormena, artea eta kultura lantzeko ekintzak.",
        irudiak: [
            "irudiak/KULTURALA/kulturala1.jpeg",
            "irudiak/KULTURALA/kulturala2.jpeg",
            "irudiak/KULTURALA/kulturala3.jpeg",
            "irudiak/KULTURALA/kulturala4.jpg",
            "irudiak/KULTURALA/kulturala5.jpg"
        ]
    },

    NATURA: {
        izena: "Natura",
        deskribapena: "Naturarekin harremanetan egoteko eta ingurunea ezagutzeko ekintzak.",
        irudiak: [
            "irudiak/NATURA/natura1.jpeg",
            "irudiak/NATURA/natura2.jpeg",
            "irudiak/NATURA/natura3.jpeg",
            "irudiak/NATURA/natura4.jpeg",
            "irudiak/NATURA/natura5.png"
        ]
    },

    SUKALDARITZA: {
        izena: "Sukaldaritza",
        deskribapena: "Sukaldaritza ikasi eta errezeta berriak prestatzeko ekintzak.",
        irudiak: [
            "irudiak/SUKALDARITZA/sukaldaritza1.jpeg",
            "irudiak/SUKALDARITZA/sukaldaritza2.jpeg",
            "irudiak/SUKALDARITZA/sukaldaritza3.jpeg",
            "irudiak/SUKALDARITZA/sukaldaritza4.jpg",
            "irudiak/SUKALDARITZA/sukaldaritza5.jpeg"
        ]
    }

};


// --------------------------------------------------
// EKINTZEN ZERRENDA
// --------------------------------------------------

const ekintzak = [

    // ---------- AISIALDIA ----------

    {
        id: 1,
        izena: "Bideo-joko arratsaldea",
        kategoria: "AISIALDIA",
        data: "2026-11-15",
        lekua: "Gaztelekua",
        plazak: 16,
        deskribapena: "Jolastu, partekatu eta ezagutu jolas berriak."
    },

    {
        id: 6,
        izena: "Mahai-jolasen arratsaldea",
        kategoria: "AISIALDIA",
        data: "2026-11-22",
        lekua: "Gaztelekua",
        plazak: 14,
        deskribapena: "Mahai-jolas klasikoak eta berriak lagunekin probatzeko arratsaldea."
    },

    {
        id: 7,
        izena: "Zinema foruma",
        kategoria: "AISIALDIA",
        data: "2026-11-29",
        lekua: "Gaztelekua",
        plazak: 25,
        deskribapena: "Film bat ikusi eta ondoren taldean komentatu."
    },

    {
        id: 8,
        izena: "Karaoke gaua",
        kategoria: "AISIALDIA",
        data: "2026-12-06",
        lekua: "Gaztelekua",
        plazak: 20,
        deskribapena: "Abestu, barre egin eta giro ona partekatu."
    },

    {
        id: 9,
        izena: "Gabonetako jolas-festa",
        kategoria: "AISIALDIA",
        data: "2026-12-20",
        lekua: "Gaztelekua",
        plazak: 30,
        deskribapena: "Jolas, musika eta sorpresak Gabonak ospatzeko."
    },

    // ---------- KIROLAK ----------

    {
        id: 2,
        izena: "Kirol jardunaldia",
        kategoria: "KIROLAK",
        data: "2026-11-18",
        lekua: "Kirol instalazioak",
        plazak: 20,
        deskribapena: "Kirol desberdinak probatzeko eta taldean aritzeko aukera."
    },

    {
        id: 10,
        izena: "Futbito txapelketa",
        kategoria: "KIROLAK",
        data: "2026-11-25",
        lekua: "Kirol instalazioak",
        plazak: 24,
        deskribapena: "Talde mistoetan jokatzen den txapelketa lagunartekoa."
    },

    {
        id: 11,
        izena: "Boleibol arratsaldea",
        kategoria: "KIROLAK",
        data: "2026-12-02",
        lekua: "Kiroldegia",
        plazak: 18,
        deskribapena: "Boleibolean hasteko edo maila hobetzeko saioa."
    },

    {
        id: 12,
        izena: "Eskalada saioa",
        kategoria: "KIROLAK",
        data: "2026-12-09",
        lekua: "Eskalada horma",
        plazak: 10,
        deskribapena: "Eskaladaren oinarriak ikasi monitore baten laguntzarekin."
    },

    {
        id: 13,
        izena: "Igeriketa eta jolasak",
        kategoria: "KIROLAK",
        data: "2026-12-16",
        lekua: "Igerilekua",
        plazak: 16,
        deskribapena: "Uretan jolastu eta igeriketa teknika erraz batzuk landu."
    },

    // ---------- KULTURALA ----------

    {
        id: 3,
        izena: "Sormen tailerra",
        kategoria: "KULTURALA",
        data: "2026-11-05",
        lekua: "Gaztelekua",
        plazak: 15,
        deskribapena: "Margotu, diseinatu eta sortu zure ideiak."
    },

    {
        id: 14,
        izena: "Argazki tailerra",
        kategoria: "KULTURALA",
        data: "2026-11-26",
        lekua: "Gaztelekua",
        plazak: 12,
        deskribapena: "Mugikorrarekin argazki politagoak ateratzeko trikimailuak."
    },

    {
        id: 15,
        izena: "Antzerki saioa",
        kategoria: "KULTURALA",
        data: "2026-12-03",
        lekua: "Kultur etxea",
        plazak: 15,
        deskribapena: "Inprobisazio jolasak eta antzerki ariketak taldean."
    },

    {
        id: 16,
        izena: "Musika tailerra",
        kategoria: "KULTURALA",
        data: "2026-12-10",
        lekua: "Gaztelekua",
        plazak: 10,
        deskribapena: "Erritmoak, instrumentuak eta abesti txiki bat sortzeko aukera."
    },

    {
        id: 17,
        izena: "Idazketa sortzailea",
        kategoria: "KULTURALA",
        data: "2026-12-17",
        lekua: "Liburutegia",
        plazak: 12,
        deskribapena: "Ipuinak, poemak eta istorioak idazteko tailer lasaia."
    },

    // ---------- NATURA ----------

    {
        id: 4,
        izena: "Mendi irteera",
        kategoria: "NATURA",
        data: "2026-11-12",
        lekua: "Plaza",
        plazak: 20,
        deskribapena: "Naturaz gozatzeko talde-irteera."
    },

    {
        id: 18,
        izena: "Perretxiko ibilbidea",
        kategoria: "NATURA",
        data: "2026-11-28",
        lekua: "Ermuko inguruak",
        plazak: 15,
        deskribapena: "Perretxikoak ezagutzeko eta basoa errespetuz bisitatzeko ibilaldia."
    },

    {
        id: 19,
        izena: "Hegazti behaketa",
        kategoria: "NATURA",
        data: "2026-12-05",
        lekua: "Ermuko mendiak",
        plazak: 12,
        deskribapena: "Prismatikoekin inguruko hegaztiak ezagutzeko goiza."
    },

    {
        id: 20,
        izena: "Baratza komunitarioa",
        kategoria: "NATURA",
        data: "2026-12-12",
        lekua: "Gaztelekuko baratza",
        plazak: 14,
        deskribapena: "Lurra lantzen ikasi eta neguko landareak ereiteko tailerra."
    },

    {
        id: 21,
        izena: "Zuhaitzak landatzea",
        kategoria: "NATURA",
        data: "2026-12-19",
        lekua: "Ermuko parkea",
        plazak: 25,
        deskribapena: "Zuhaitz berriak landatu eta ingurumena zaintzeko ekimena."
    },

    // ---------- SUKALDARITZA ----------

    {
        id: 5,
        izena: "Sukaldaritza gaztea",
        kategoria: "SUKALDARITZA",
        data: "2026-11-08",
        lekua: "Sukaldea",
        plazak: 12,
        deskribapena: "Errezeta errazak eta talde-lana."
    },

    {
        id: 22,
        izena: "Pizza tailerra",
        kategoria: "SUKALDARITZA",
        data: "2026-11-27",
        lekua: "Sukaldea",
        plazak: 12,
        deskribapena: "Orea egin, osagaiak aukeratu eta zure pizza prestatu."
    },

    {
        id: 23,
        izena: "Postre goxoak",
        kategoria: "SUKALDARITZA",
        data: "2026-12-04",
        lekua: "Sukaldea",
        plazak: 12,
        deskribapena: "Postre errazak eta ederrak egiten ikasi."
    },

    {
        id: 24,
        izena: "Munduko sukaldaritza",
        kategoria: "SUKALDARITZA",
        data: "2026-12-11",
        lekua: "Sukaldea",
        plazak: 10,
        deskribapena: "Beste herrialde batzuetako plater tipikoak prestatu eta dastatu."
    },

    {
        id: 25,
        izena: "Gabonetako galletak",
        kategoria: "SUKALDARITZA",
        data: "2026-12-18",
        lekua: "Sukaldea",
        plazak: 14,
        deskribapena: "Galletak egin eta apaintzeko tailer goxoa."
    }

];
